<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Kategori;
use App\Models\Pengaduan;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function __invoke(): View
    {
        $hitung = Pengaduan::query()->pluck('status')->countBy();

        // Data 12 bulan terakhir (dihitung di PHP agar jalan di MySQL maupun SQLite)
        $awal = now()->startOfMonth()->subMonths(11);
        $perBulan = Pengaduan::where('created_at', '>=', $awal)
            ->get(['created_at', 'status'])
            ->groupBy(fn ($p) => $p->created_at->format('Y-m'));

        $bulan = collect(range(0, 11))->map(function ($i) use ($awal, $perBulan) {
            $b = $awal->copy()->addMonths($i);
            $baris = $perBulan->get($b->format('Y-m'), collect());

            return [
                'label' => $b->translatedFormat('M'),
                'penuh' => $b->translatedFormat('F Y'),
                'pending' => $baris->where('status', Pengaduan::PENDING)->count(),
                'approved' => $baris->where('status', Pengaduan::APPROVED)->count(),
                'rejected' => $baris->where('status', Pengaduan::REJECTED)->count(),
            ];
        })->values();

        $kategori = Kategori::withCount('pengaduan')
            ->orderByDesc('pengaduan_count')->orderBy('nama')
            ->take(6)->get()
            ->map(fn ($k) => ['nama' => $k->nama, 'jumlah' => $k->pengaduan_count])
            ->filter(fn ($k) => $k['jumlah'] > 0)->values();

        $status = [
            'pending' => (int) ($hitung[Pengaduan::PENDING] ?? 0),
            'approved' => (int) ($hitung[Pengaduan::APPROVED] ?? 0),
            'rejected' => (int) ($hitung[Pengaduan::REJECTED] ?? 0),
        ];

        return view('admin.dashboard', [
            'total' => array_sum($status),
            'pending' => $status['pending'],
            'approved' => $status['approved'],
            'rejected' => $status['rejected'],
            'chartData' => compact('bulan', 'status', 'kategori'),
            'terbaru' => Pengaduan::with(['pelapor', 'kategori'])->latest()->take(6)->get(),
        ]);
    }
}
