<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Pengaduan extends Model
{
    protected $table = 'pengaduan';

    public const PENDING = 'pending';
    public const APPROVED = 'approved';
    public const REJECTED = 'rejected';

    public const STATUS = [self::PENDING, self::APPROVED, self::REJECTED];

    protected $fillable = [
        'user_id', 'kategori_id', 'sarana_id', 'lokasi', 'tanggal_kejadian',
        'deskripsi', 'foto', 'status', 'tanggapan', 'diverifikasi_oleh', 'diverifikasi_pada',
    ];

    protected function casts(): array
    {
        return [
            'tanggal_kejadian' => 'date',
            'diverifikasi_pada' => 'datetime',
        ];
    }

    public function pelapor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function verifikator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'diverifikasi_oleh');
    }

    public function kategori(): BelongsTo
    {
        return $this->belongsTo(Kategori::class);
    }

    public function sarana(): BelongsTo
    {
        return $this->belongsTo(Sarana::class);
    }

    /** Nomor tiket seperti di wireframe: #0012 */
    public function kode(): string
    {
        return '#'.str_pad((string) $this->id, 4, '0', STR_PAD_LEFT);
    }

    public function fotoUrl(): ?string
    {
        return $this->foto ? asset('storage/'.$this->foto) : null;
    }

    public function statusLabel(): string
    {
        return ucfirst($this->status);
    }

    public function scopeStatus($query, ?string $status)
    {
        return in_array($status, self::STATUS, true) ? $query->where('status', $status) : $query;
    }
}
