<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Masuk — ADUKANAJA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
<div class="auth-wrap">
    <div class="auth-box">
        <div class="auth-brand">
            <div class="logo">A</div>
            <h1>ADUKANAJA</h1>
            <p>Sistem Pengaduan Sarana Sekolah</p>
        </div>

        @if (session('error')) <div class="alert alert-error" role="alert">{{ session('error') }}</div> @endif
        @if (session('success')) <div class="alert alert-success" role="status">{{ session('success') }}</div> @endif

        <form class="card card-pad" method="POST" action="{{ route('login.proses') }}" novalidate>
            @csrf

            <div class="field @error('login') has-error @enderror">
                <label for="login">Email / NIS</label>
                <input id="login" name="login" type="text" value="{{ old('login') }}" autocomplete="username" autofocus required>
                @error('login') <p class="field-error">{{ $message }}</p> @enderror
            </div>

            <div class="field @error('password') has-error @enderror">
                <label for="password">Password</label>
                <input id="password" name="password" type="password" autocomplete="current-password" required>
                @error('password') <p class="field-error">{{ $message }}</p> @enderror
            </div>

            <button class="btn btn-dark btn-block" type="submit">Masuk</button>
            <p class="muted small center mt">Lupa password? Hubungi admin sekolah.</p>
        </form>
    </div>
</div>
</body>
</html>
