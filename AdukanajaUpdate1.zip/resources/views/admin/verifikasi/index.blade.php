@extends('layouts.app')
@section('title', 'Verifikasi Pengaduan')

@section('content')
    <div class="page-head"><h1>Verifikasi Pengaduan Masuk</h1></div>

    <div class="grid grid-split">
        {{-- ===== Kiri: daftar pengaduan ===== --}}
        <aside>
            <div class="chips">
                @foreach ([null => 'Semua', 'pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected'] as $v => $l)
                    <a class="chip @if ($status === $v) on @endif" href="{{ route('admin.verifikasi', array_filter(['status' => $v])) }}">{{ $l }}</a>
                @endforeach
            </div>

            @forelse ($daftar as $p)
                <a class="pick s-{{ $p->status }} @if ($dipilih && $dipilih->id === $p->id) on @endif"
                   href="{{ route('admin.verifikasi', array_filter(['id' => $p->id, 'status' => $status])) }}#detail">
                    <div class="pick-top"><span>{{ $p->kode() }} · {{ $p->kategori->nama }}</span><x-status-badge :status="$p->status" /></div>
                    <div class="ticket-meta">{{ $p->pelapor->name }} · {{ $p->lokasi }} · {{ $p->created_at->translatedFormat('d M Y') }}</div>
                </a>
            @empty
                <div class="card"><x-empty>Tidak ada pengaduan.</x-empty></div>
            @endforelse

            @if ($daftar->hasPages()) <div class="card" style="margin-top:10px">{{ $daftar->links() }}</div> @endif
        </aside>

        {{-- ===== Kanan: detail & form verifikasi ===== --}}
        <section class="card card-pad" id="detail">
            @if (! $dipilih)
                <x-empty>Pilih pengaduan di sebelah kiri untuk memverifikasi.</x-empty>
            @else
                <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:14px">
                    <span class="label" style="margin:0">Detail pengaduan {{ $dipilih->kode() }}</span>
                    <x-status-badge :status="$dipilih->status" />
                </div>

                @if ($dipilih->fotoUrl())
                    <a class="detail-photo" href="#foto-besar" title="Klik untuk memperbesar"><img src="{{ $dipilih->fotoUrl() }}" alt="Foto bukti kerusakan"></a>
                    <a class="lightbox" id="foto-besar" href="#"><img src="{{ $dipilih->fotoUrl() }}" alt="Foto bukti kerusakan (diperbesar)"></a>
                @else
                    <div class="no-photo">Pelapor tidak melampirkan foto</div>
                @endif

                <dl class="meta">
                    <dt>Pelapor</dt><dd>{{ $dipilih->pelapor->name }}@if ($dipilih->pelapor->kelas) <span class="muted">({{ $dipilih->pelapor->kelas }})</span>@endif</dd>
                    <dt>Kategori</dt><dd>{{ $dipilih->kategori->nama }}</dd>
                    <dt>Lokasi</dt><dd>{{ $dipilih->lokasi }}@if ($dipilih->sarana) <span class="muted">· {{ $dipilih->sarana->nama }}</span>@endif</dd>
                    <dt>Tgl. kejadian</dt><dd>{{ $dipilih->tanggal_kejadian->translatedFormat('d F Y') }}</dd>
                    <dt>Deskripsi</dt><dd style="white-space:pre-line">{{ $dipilih->deskripsi }}</dd>
                    @if ($dipilih->verifikator)
                        <dt>Terakhir diubah</dt><dd class="muted">{{ $dipilih->verifikator->name }}, {{ $dipilih->diverifikasi_pada?->translatedFormat('d M Y H:i') }}</dd>
                    @endif
                </dl>

                <form method="POST" action="{{ route('admin.verifikasi.update', $dipilih) }}" novalidate>
                    @csrf @method('PUT')
                    <input type="hidden" name="filter_status" value="{{ $status }}">

                    <div class="field @error('status') has-error @enderror">
                        <span class="label">Ubah status penanganan</span>
                        <div class="pills">
                            @foreach (['approved' => 'Approved', 'pending' => 'Pending', 'rejected' => 'Rejected'] as $v => $l)
                                <label class="pill pill-{{ $v }}">
                                    <input type="radio" name="status" value="{{ $v }}" @checked(old('status', $dipilih->status) === $v)>
                                    <span>{{ $l }}</span>
                                </label>
                            @endforeach
                        </div>
                        @error('status') <p class="field-error">{{ $message }}</p> @enderror
                    </div>

                    <div class="field @error('tanggapan') has-error @enderror">
                        <label for="tanggapan">Catatan tanggapan</label>
                        <textarea id="tanggapan" name="tanggapan" placeholder="Tindak lanjut perbaikan, jadwal, atau alasan penolakan…">{{ old('tanggapan', $dipilih->tanggapan) }}</textarea>
                        <p class="hint">Wajib diisi jika status Rejected. Catatan ini tampil di riwayat siswa.</p>
                        @error('tanggapan') <p class="field-error">{{ $message }}</p> @enderror
                    </div>

                    <button class="btn btn-dark" type="submit">Simpan Status</button>
                </form>
            @endif
        </section>
    </div>
@endsection
