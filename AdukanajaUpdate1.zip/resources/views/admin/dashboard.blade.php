@extends('layouts.app')
@section('title', 'Dashboard')

@section('content')
    <div class="page-head">
        <div>
            <h1>Dashboard Admin</h1>
            <p>Rekap pengaduan sarana sekolah secara keseluruhan.</p>
        </div>
        @if ($pending > 0)
            <a class="btn btn-primary" href="{{ route('admin.verifikasi', ['status' => 'pending']) }}">Verifikasi {{ $pending }} pengaduan pending →</a>
        @endif
    </div>

    <div class="grid grid-4">
        <div class="card stat"><div class="label">Total</div><div class="value">{{ $total }}</div></div>
        <div class="card stat warning"><div class="label">Pending</div><div class="value">{{ $pending }}</div></div>
        <div class="card stat success"><div class="label">Approved</div><div class="value">{{ $approved }}</div></div>
        <div class="card stat error"><div class="label">Rejected</div><div class="value">{{ $rejected }}</div></div>
    </div>

    <div class="chart-grid mt-lg">
        <div class="card chart-card">
            <div class="chart-head">
                <div class="label">Pengaduan per bulan</div>
                <div class="seg" role="group" aria-label="Rentang waktu">
                    <button type="button" data-range="6" class="on">6 bln</button>
                    <button type="button" data-range="12">12 bln</button>
                </div>
            </div>
            <div id="chart-bulan"></div>
        </div>
        <div class="card chart-card">
            <div class="label" style="margin-bottom:12px">Komposisi status</div>
            <div id="chart-status"></div>
        </div>
    </div>

    <div class="chart-grid">
        <div class="card chart-card">
            <div class="label" style="margin-bottom:8px">Kategori terbanyak</div>
            <div id="chart-kategori"></div>
        </div>
        <div class="card" style="min-width:0">
            <div class="chart-card" style="padding-bottom:6px"><div class="label" style="margin:0">Pengaduan terbaru</div></div>
            @if ($terbaru->isEmpty())
                <x-empty>Belum ada pengaduan masuk.</x-empty>
            @else
                <div class="table-wrap">
                    <table class="stack">
                        <thead><tr><th>Siswa</th><th>Kategori</th><th>Lokasi</th><th>Status</th><th>Aksi</th></tr></thead>
                        <tbody>
                        @foreach ($terbaru as $p)
                            <tr>
                                <td data-label="Siswa">{{ $p->pelapor->name }}</td>
                                <td data-label="Kategori">{{ $p->kategori->nama }}</td>
                                <td data-label="Lokasi">{{ $p->lokasi }}</td>
                                <td data-label="Status"><x-status-badge :status="$p->status" /></td>
                                <td data-label="Aksi"><a href="{{ route('admin.verifikasi', ['id' => $p->id]) }}#detail">Tinjau</a></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>
@endsection

@push('scripts')
    <script id="chart-data" type="application/json">@json($chartData)</script>
    <script src="{{ asset('js/charts.js') }}"></script>
@endpush
