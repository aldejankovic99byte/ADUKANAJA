<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>@yield('title', 'Beranda') — ADUKANAJA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
@php
    $user = auth()->user();

    // ikon garis sederhana (SVG) untuk tab bar di HP
    $ikon = [
        'home' => '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
        'tambah' => '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
        'riwayat' => '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',
        'profil' => '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
        'dashboard' => '<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>',
        'pengguna' => '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-3.5 3-5.5 7-5.5s7 2 7 5.5"/><path d="M16 4.5a3.5 3.5 0 010 7M18 14.5c2.5.6 4 2.3 4 5.5"/>',
        'sarana' => '<path d="M3 7l9-4 9 4v10l-9 4-9-4z"/><path d="M3 7l9 4 9-4M12 11v10"/>',
        'verifikasi' => '<circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/>',
        'laporan' => '<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
    ];

    $menu = $user->isAdmin()
        ? [
            ['Dashboard', 'dashboard', route('admin.dashboard'), request()->routeIs('admin.dashboard')],
            ['Pengguna', 'pengguna', route('admin.pengguna.index'), request()->routeIs('admin.pengguna.*')],
            ['Sarana', 'sarana', route('admin.sarana.index'), request()->routeIs('admin.sarana.*', 'admin.kategori.*')],
            ['Verifikasi', 'verifikasi', route('admin.verifikasi'), request()->routeIs('admin.verifikasi*')],
            ['Laporan', 'laporan', route('admin.laporan'), request()->routeIs('admin.laporan*')],
        ]
        : [
            ['Beranda', 'home', route('beranda'), request()->routeIs('beranda')],
            ['Ajukan', 'tambah', route('pengaduan.create'), request()->routeIs('pengaduan.create')],
            ['Riwayat', 'riwayat', route('pengaduan.riwayat'), request()->routeIs('pengaduan.riwayat', 'pengaduan.show')],
            ['Profil', 'profil', route('profil'), request()->routeIs('profil')],
        ];
@endphp

<header class="topbar">
    <div class="topbar-inner">
        <a class="brand" href="{{ route('home') }}">ADUKANAJA @if($user->isAdmin())<small>/ admin</small>@endif</a>

        <nav class="nav" aria-label="Menu utama">
            @foreach ($menu as [$label, $ik, $url, $active])
                <a href="{{ $url }}" @class(['active' => $active]) @if($active) aria-current="page" @endif>
                    <svg class="nav-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{!! $ikon[$ik] !!}</svg>
                    <span>{{ $label }}</span>
                </a>
            @endforeach
        </nav>

        <details class="user-menu" id="user-menu">
            <summary aria-label="Menu akun">
                <x-avatar :user="$user" size="sm" />
                <span class="user-name">{{ $user->name }}</span>
            </summary>
            <div class="menu-pop">
                <div class="role"><strong>{{ $user->name }}</strong>{{ $user->roleLabel() }}</div>
                <a href="{{ route('profil') }}">Profil &amp; foto</a>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit">Keluar</button>
                </form>
            </div>
        </details>
    </div>
</header>

<main class="container">
    @if (session('success'))
        <div class="alert alert-success" role="status">{{ session('success') }}</div>
    @endif
    @if (session('error'))
        <div class="alert alert-error" role="alert">{{ session('error') }}</div>
    @endif

    @yield('content')
</main>

<script>
    // tutup menu akun saat klik di luar
    document.addEventListener('click', function (e) {
        var m = document.getElementById('user-menu');
        if (m && m.open && !m.contains(e.target)) m.open = false;
    });
</script>
@stack('scripts')
</body>
</html>
