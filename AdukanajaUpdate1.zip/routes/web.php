<?php

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\KategoriController;
use App\Http\Controllers\Admin\LaporanController;
use App\Http\Controllers\Admin\PenggunaController;
use App\Http\Controllers\Admin\SaranaController;
use App\Http\Controllers\Admin\VerifikasiController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ProfilController;
use App\Http\Controllers\Siswa\BerandaController;
use App\Http\Controllers\Siswa\PengaduanController;
use Illuminate\Support\Facades\Route;

// Halaman awal: arahkan sesuai role
Route::get('/', function () {
    $user = auth()->user();

    if (! $user) {
        return redirect()->route('login');
    }

    return redirect()->route($user->isAdmin() ? 'admin.dashboard' : 'beranda');
})->name('home');

// ---------- Autentikasi (FR-01) ----------
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:10,1')->name('login.proses');
});

Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    // Profil & ubah password (semua role)
    Route::get('/profil', [ProfilController::class, 'edit'])->name('profil');
    Route::put('/profil', [ProfilController::class, 'update'])->name('profil.update');
    Route::put('/profil/password', [ProfilController::class, 'password'])->name('profil.password');
    Route::post('/profil/foto', [ProfilController::class, 'foto'])->name('profil.foto');
    Route::delete('/profil/foto', [ProfilController::class, 'hapusFoto'])->name('profil.foto.hapus');

    // ---------- Siswa (FR-03) ----------
    Route::middleware('role:siswa')->group(function () {
        Route::get('/beranda', BerandaController::class)->name('beranda');
        Route::get('/pengaduan/ajukan', [PengaduanController::class, 'create'])->name('pengaduan.create');
        Route::post('/pengaduan', [PengaduanController::class, 'store'])->name('pengaduan.store');
        Route::get('/riwayat', [PengaduanController::class, 'index'])->name('pengaduan.riwayat');
        Route::get('/pengaduan/{pengaduan}', [PengaduanController::class, 'show'])->name('pengaduan.show');
    });

    // ---------- Admin / Petugas ----------
    Route::prefix('admin')->name('admin.')->middleware('role:admin')->group(function () {
        Route::get('/dashboard', DashboardController::class)->name('dashboard');          // FR-05

        // FR-02 Master data
        Route::resource('pengguna', PenggunaController::class)->parameters(['pengguna' => 'user'])->except('show');
        Route::resource('sarana', SaranaController::class)->except('show');
        Route::resource('kategori', KategoriController::class)->except(['index', 'show']);

        // FR-04 Verifikasi
        Route::get('/verifikasi', [VerifikasiController::class, 'index'])->name('verifikasi');
        Route::put('/verifikasi/{pengaduan}', [VerifikasiController::class, 'update'])->name('verifikasi.update');

        // FR-05 Laporan
        Route::get('/laporan', [LaporanController::class, 'index'])->name('laporan');
        Route::get('/laporan/excel', [LaporanController::class, 'excel'])->name('laporan.excel');
        Route::get('/laporan/cetak', [LaporanController::class, 'cetak'])->name('laporan.cetak');
    });
});
